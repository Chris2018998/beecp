package test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

public class TestResultPrint {
	static Logger log = Logger.getLogger(TestResultPrint.class);

	public static List<Object> printSummary(String datasource, String testName, TestResult[] threads, int threadCount,
			int loopCount, int scale) {

		BigDecimal totalCount = new BigDecimal(threadCount * loopCount);
		long minTime = -1, maxTime = -1;
		BigDecimal gapTime = new BigDecimal(0);
		BigDecimal totalSuccessTime = new BigDecimal(0);
		BigDecimal failCount = new BigDecimal(0);
		BigDecimal successCount = new BigDecimal(0);

		int mill0 = 0, mill10 = 0, mill30 = 0, mill50 = 0, mill100 = 0;
		int mill200 = 0, mill500 = 0, mill1000 = 0, mill2000 = 0, mill2000M = 0;

		for (int i = 0; i < threadCount; i++) {
			failCount = failCount.add(new BigDecimal(threads[i].getFailedCount()));
			successCount = successCount.add(new BigDecimal(threads[i].getSuccessCount()));
			long[] startTime = threads[i].getStartTime();
			long[] endTime = threads[i].getEndTime();

			for (int j = 0; j < loopCount; j++) {
				if (endTime[j] == 0)
					continue;
				gapTime = new BigDecimal(endTime[j]).subtract(new BigDecimal(startTime[j]));
				totalSuccessTime = totalSuccessTime.add(gapTime);
				gapTime = new BigDecimal(TimeUnit.NANOSECONDS.toMillis(gapTime.longValue()));
				totalSuccessTime = totalSuccessTime.add(gapTime);
				long tempTime = gapTime.longValue();

				if (tempTime <= 0) {
					mill0++;
				} else if (0 < tempTime && tempTime <= 10) {
					mill10++;
				} else if (10 < tempTime && tempTime <= 30) {
					mill30++;
				} else if (30 < tempTime && tempTime <= 50) {
					mill50++;
				} else if (50 < tempTime && tempTime <= 100) {
					mill100++;
				} else if (100 < tempTime && tempTime <= 200) {
					mill200++;
				} else if (200 < tempTime && tempTime <= 500) {
					mill500++;
				} else if (500 < tempTime && tempTime <= 1000) {
					mill1000++;
				} else if (1000 < tempTime && tempTime <= 2000) {
					mill2000++;
				} else {
					mill2000M++;
				}

				if (minTime == -1)
					minTime = tempTime;
				if (maxTime == -1)
					maxTime = tempTime;

				if (minTime > tempTime)
					minTime = tempTime;
				if (maxTime < tempTime)
					maxTime = tempTime;
			}
		}

		totalSuccessTime =new BigDecimal(TimeUnit.NANOSECONDS.toMillis(totalSuccessTime.longValue()));
		BigDecimal minTimeDecimal = new BigDecimal(minTime);
		BigDecimal maxTimeDecimal = new BigDecimal(maxTime);
		List<Object> resultList = new ArrayList<Object>();

		resultList.add(successCount.longValue());// 0
		resultList.add(failCount.longValue());// 1
		resultList.add(totalSuccessTime.divide(successCount, 4, BigDecimal.ROUND_HALF_UP));// 2
		resultList.add(minTime);// 3
		resultList.add(maxTime);// 4

		resultList.add(mill0);// 4
		resultList.add(mill10);// 6
		resultList.add(mill30);// 7
		resultList.add(mill50);// 8
		resultList.add(mill100);// 9
		resultList.add(mill200);// 10
		resultList.add(mill500);// 11
		resultList.add(mill1000);// 12
		resultList.add(mill2000);// 13
		resultList.add(mill2000M);//14

		log.info("连接池["+datasource+"]--("+testName+")执行次数:"+ totalCount.toPlainString() + ",总耗时:"
				+ totalSuccessTime.toPlainString() + "ms,平均耗时:"
				+ (totalSuccessTime.divide(successCount, scale, BigDecimal.ROUND_HALF_UP).toPlainString()) + "ms"
				+ ",毫秒吞吐量:" + (successCount.divide(totalSuccessTime, 2, BigDecimal.ROUND_HALF_UP).toPlainString())
				+ ",最小执行时间:" + minTimeDecimal.toPlainString() + "ms,最大执行时间:" + maxTimeDecimal.toPlainString() + "ms");

		log.info("success count       :" + successCount);
		log.info("fail count          :" + failCount);
		log.info("avr(ms)             :"+ (totalSuccessTime.divide(successCount, 4, BigDecimal.ROUND_HALF_UP).toPlainString()));
		log.info("min(ms)             :" + minTime);
		log.info("max(ms)             :" + maxTime);
		log.info("time=0ms            :" + mill0);
		log.info("0ms<time<=10ms      :" + mill10);
		log.info("10ms<time<=30ms     :" + mill30);
		log.info("30ms<time<=50ms     :" + mill50);
		log.info("50ms<time<=100ms    :" + mill100);
		log.info("100ms<time<=200ms   :" + mill200);
		log.info("200ms<time<=500ms   :" + mill500);
		log.info("500ms<time<=1000ms  :" + mill1000);
		log.info("1000ms<time<=2000ms :" + mill2000);
		log.info("2000ms<time         :" + mill2000M);
		return resultList;
	}
	
	public static void printAnalysis(String allPoolNames,String testName,List<TestAvg> arvgList,List<List<Object>> allPoolResultList) {
		StringBuffer buf = new StringBuffer();
		buf.append("["+testName+"]性能分析排行结果:");
		Collections.sort(arvgList);
		for (int i = 0; i < arvgList.size(); i++) {
			if (i > 0)
				buf.append(" > ");
			TestAvg avg = arvgList.get(i);
			buf.append(avg.getPoolName() + "(" + avg.getAvgValue().toPlainString() + ")");
		}
		log.info(buf);
		
		StringBuffer headBuffer = new StringBuffer();
		StringBuffer headBuffer2 = new StringBuffer();
		headBuffer.append("|Sumary|").append(allPoolNames.replaceAll(",", "|")).append("|");
		String head = headBuffer.toString();
		headBuffer2.append("|");
		int index =1;
		while((index=head.indexOf("|",index+1))!=-1 ){
			headBuffer2.append(" --- ").append("|");
		}
		
		List<StringBuffer> tabelList= new ArrayList<StringBuffer>(15);
		for(int i=0;i<15;i++){
			tabelList.add(new StringBuffer());
		}
		tabelList.get(0).append("|success Count");
		tabelList.get(1).append("|fail count");
		tabelList.get(2).append("|avr(ms)");
		tabelList.get(3).append("|min(ms)");
		tabelList.get(4).append("|max(ms)");
		tabelList.get(5).append("|time=0ms");
		tabelList.get(6).append("|0ms<time<=10ms");
		tabelList.get(7).append("|10ms<time<=30ms");
		tabelList.get(8).append("|30ms<time<=50ms");
		tabelList.get(9).append("|50ms<time<=100ms");
		tabelList.get(10).append("|100ms<time<=200ms");
		tabelList.get(11).append("|200ms<time<=500ms");
		tabelList.get(12).append("|500ms<time<=1000ms");
		tabelList.get(13).append("|1000ms<time<=2000ms");
		tabelList.get(14).append("|2000ms<time");
		
		int pos=0;
		for(int j=0;j<15;j++){
		    StringBuffer tempBuf = tabelList.get(j);
		    tempBuf.append("|");
		    for(int n=0;n<allPoolResultList.size();n++){
		    	List<Object> resultList = allPoolResultList.get(n);
		    	tempBuf.append(resultList.get(pos)).append("|");
		    }  
		    pos++;
		    if(j==14)tempBuf.append("|");
		}
		
		log.info(headBuffer);
		log.info(headBuffer2);
		for(int j=0;j<15;j++){
			log.info(tabelList.get(j));
		}
	}
}
