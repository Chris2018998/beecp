package test.type;

import org.jmin.bee.BeeDataSource;
import org.jmin.bee.impl.connection.JdbcPoolConfig;

import test.Link;

/**
 * a Lightweight pool 
 * 
 */
public class BeeCP_C {

	private static BeeDataSource datasource;

	static {
		try {
			initDataSource();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void initDataSource() throws Exception{
		JdbcPoolConfig sourceInfo = new JdbcPoolConfig(Link.JDBC_DRIVER, 
				Link.JDBC_URL,
				Link.JDBC_USER, 
				Link.JDBC_PASSWORD);

		sourceInfo.setPoolMaxSize(Link.POOL_MAX_ACTIVE);
		sourceInfo.setPoolInitSize(Link.POOL_INIT_SIZE);
		sourceInfo.setBorrowerMaxWaitTime(Link.REQUEST_TIMEOUT);
		sourceInfo.setPreparedStatementCacheSize(20);
		sourceInfo.setConnectionValidateSQL("select 1");
		sourceInfo.addProperty("cachePrepStmts", "true");
		sourceInfo.addProperty("prepStmtCacheSize", "250");
		sourceInfo.addProperty("prepStmtCacheSqlLimit", "2048");
		datasource = new BeeDataSource(sourceInfo);
	}  	
   
	public static BeeDataSource getDatasource() {
		return datasource;
	}
}
