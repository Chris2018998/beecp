package test.type;
import java.util.Properties;

import org.vibur.dbcp.ViburDBCPDataSource;

import test.Link;

public class Vibur {
	private static ViburDBCPDataSource datasource;
	static{
		initDataSource();
	}
	public static void initDataSource() {
		Properties properties =new Properties();
		datasource = new ViburDBCPDataSource(properties);   
		datasource.setUsername(Link.JDBC_USER);
		datasource.setPassword(Link.JDBC_PASSWORD);
		datasource.setDriverClassName(Link.JDBC_DRIVER);
		datasource.setJdbcUrl(Link.JDBC_URL);
		datasource.setPoolInitialSize(Link.POOL_INIT_SIZE);
		datasource.setPoolMaxSize(Link.POOL_MAX_ACTIVE);
		datasource.setStatementCacheMaxSize(20);
		datasource.setConnectionTimeoutInMs(Link.REQUEST_TIMEOUT);
		datasource.setTestConnectionQuery("select 1");
		datasource.start();
	}
	public static ViburDBCPDataSource getDatasource() {
		return datasource;
	}
}
