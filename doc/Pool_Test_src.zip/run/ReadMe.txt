﻿工具说明：测试Java主流连接池池并发性能

一：测试性能目标(公平起见，取各自的最新版本）
1：单线程取100万次连接耗时，计算平均每次时间
2：单线程取100万次查询耗时，计算平均每次时间
3：N个线程取连接,每个线程循环M次,计算平均每次时间
4: N个线程查询,每个线程循环M次,计算平均每次时间

二：测试目标连接池: DBCP DBCP2 C3P0 TOMCAT Vibur Druid HikariCP Bee
   DBCP     :老牌连接池
   DBCP2    :老牌连接池
   C3P0     :老牌连接池
   TOMCAT   :Tomcat提供一个连接池实现
   Vibur    :
   Druid    : 阿里作品
   HikariCP : 光连接池，最快的连接池,美国高人开发
   Bee      :

三：测试工具：JAVA8（推荐64位，不可低于Java8），Mysql(推荐mysql-5.6.40_64，减少网络开销，与Java同在一台机器)，Ant

四：测试环境：windows(推荐Win_64 Server),CPU:赫兹尽量高(推荐最新版本I7多核)，内存：尽量高（推荐16G内存）

五：测试准备：
1：创建一个空库(推荐名采用MYSQL自带库:test,其他名字请修改Link.properties)

2：创建一个一张空表(推荐表名：TEST_USER，其他名字请修改Link.properties）
   CREATE TABLE TEST_USER(
     USER_ID             VARCHAR(10),
     USER_NAME           VARCHAR(10) 
   );
   
六：测试执行前,请修改文件：setJAVA_HOME.bat设置JAVA_HOME环境变量指向您本地Java8

七：测试执行：用鼠标双击文件：Testxxx.bat文件，会在当前目录产生一个日志输出文件：JDBCPool.log ,
   如果您本地存在ant工具，则可以执行文件：RunAntBatch如果您本地存在ant工具批量执行各个连接池测试(点前,要编辑修改文件中的ant_home变量）
   
友好提示：
1:由于本人不是很熟悉上述连接池，可能存在参数设置不当，导致性能未能尽致发挥。您可以依据自身环境调整代码，编译后可以以Jar包方式替换lib/performance.jar
 
 
 
 
 











