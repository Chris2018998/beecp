﻿* Source code for connection pools performance test


I: Borrow performance and query performance
1: Borrow, 1000 Thread to execute 1000 iterate [datasource.getConenciton(), conneciton.close()].
2: Query, 1000 Thread to execute 1000 iterate [datasource.getConenciton(), conneciton.prepareStatement(), statement.execute(), conneciton.close()].


Then print performance result
A: total time for all iterate
B: average time per time
C: sectional statistics by per time


* II: Compared JDBC pool list
1: DBCP, Old-fashioned connection pool
2: DBCP2: Old-fashioned connection pool
3: C3P0: Old Connection Pool
4: TOMCAT-JDBC: TOMCAT new product
5: Vibur:
6: Druid: best in China,develop by AILI(A big Chinese Internet company)
7: HikariCP: '光' means the fastest connection pool,created by an America expert
8: BeeCP:my individual product to build light-weight one

* III: Performance test Requirement
1: JAVA8 (recommended 64 bits, not less than Java 8)
2: MySQL (recommended MySQL-5.6.40_64)
3: CPU: Hertz as high as possible (recommended the latest version of I7 Multi-core)
4: Memory: as high as possible (recommended 16G memory)


* IV: Performance execution bat file
a: Borrow, run/TestMutilBorrow.bat

b: Query, run/TestMutilQuery.bat


* V: Performance test configuration file,Link.properties
 
    DROP TABLE TEST_USER;
    CREATE TABLE TEST_USER（
      USER_ID VARCHAR (10),
      USER_NAME VARCHAR(10)
   );
   
    INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test1','Test1');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test2','Test2');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test3','Test3');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test4','Test4');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test5','Test5');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test6','Test6');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test7','Test7');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test8','Test8');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test9','Test9');
	INSERT INTO TEST_USER (USER_ID, USER_NAME) VALUES ('Test10','Test10');
	
	
	