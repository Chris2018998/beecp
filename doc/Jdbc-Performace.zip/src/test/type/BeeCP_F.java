package test.type;

import org.jmin.bee.BeeDataSource;
import org.jmin.bee.BeeDataSourceConfig;

import test.Link;

/**
 * fair mode for BeeCP
 * 
 */
public class BeeCP_F {

	private static BeeDataSource datasource;

	static {
		try {
			initDataSource();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void initDataSource() throws Exception{
		BeeDataSourceConfig sourceInfo = new BeeDataSourceConfig(Link.JDBC_DRIVER, 
				Link.JDBC_URL,
				Link.JDBC_USER, 
				Link.JDBC_PASSWORD);

		sourceInfo.setPoolMaxSize(Link.POOL_MAX_ACTIVE);
		sourceInfo.setPoolInitSize(Link.POOL_INIT_SIZE);
		sourceInfo.setBorrowerMaxWaitTime(Link.REQUEST_TIMEOUT);
        sourceInfo.setPreparedStatementCacheSize(10);
		sourceInfo.setValidationQuerySQL("select 1");
		
		sourceInfo.addProperty("cachePrepStmts", "true");
		sourceInfo.addProperty("prepStmtCacheSize", "250");
		sourceInfo.addProperty("prepStmtCacheSqlLimit", "2048");
		sourceInfo.setFairMode(true);
		//sourceInfo.setConnectionPoolClassName("org.jmin.bee.pool.ConnectionPool2");
 		datasource = new BeeDataSource(sourceInfo);
	}  	
	
	public static BeeDataSource getDatasource() {
		return datasource;
	}
}
