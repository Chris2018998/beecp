package test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

public class TestResultPrint {
	static Logger log = Logger.getLogger(TestResultPrint.class);

	public static List<Object> printSummary(String datasource, String testName, TestResult[] threads, int threadCount,
			int loopCount, int scale) {

		BigDecimal totalCount = new BigDecimal(threadCount * loopCount);
		long minTime = -1, maxTime = -1;
		BigDecimal gapTime = new BigDecimal(0);
		BigDecimal totalSuccessTime = new BigDecimal(0);
		BigDecimal failCount = new BigDecimal(0);
		BigDecimal successCount = new BigDecimal(0);

		int mill0 = 0,mill1 = 0, mill2 = 0, mill3 = 0, mill4 = 0,mill5 = 0;
		int mill10 = 0, mill30 = 0, mill50 = 0, mill100 = 0;
		int mill200 = 0, mill500 = 0, mill1000 = 0,mill2000 = 0,mill2000M = 0;
	
		for (int i = 0; i < threadCount; i++) {
			failCount = failCount.add(new BigDecimal(threads[i].getFailedCount()));
			successCount = successCount.add(new BigDecimal(threads[i].getSuccessCount()));
			long[] startTime = threads[i].getStartTime();
			long[] endTime = threads[i].getEndTime();

			for (int j = 0; j < loopCount; j++) {
				if (endTime[j] == 0)continue;

				gapTime = new BigDecimal(endTime[j]).subtract(new BigDecimal(startTime[j]));
				totalSuccessTime = totalSuccessTime.add(gapTime);
				
				gapTime = new BigDecimal(TimeUnit.NANOSECONDS.toMillis(gapTime.longValue()));//nano to millis
				long tempTime = gapTime.longValue();
				
				if (tempTime == 0) {
					mill0++;
				} else if (tempTime == 1) {
					mill1++;
				} else if (tempTime == 2) {
					mill2++;
				} else if (tempTime == 3) {
					mill3++;
				} else if (tempTime == 4) {
					mill4++;
				} else if (tempTime == 5) {
					mill5++;
				} else if (5 < tempTime && tempTime <= 10) {
					mill10++;
				} else if (10 < tempTime && tempTime <= 30) {
					mill30++;
				} else if (30 < tempTime && tempTime <= 50) {
					mill50++;
				} else if (50 < tempTime && tempTime <= 100) {
					mill100++;
				} else if (100 < tempTime && tempTime <= 200) {
					mill200++;
				} else if (200 < tempTime && tempTime <= 500) {
					mill500++;
				} else if (500 < tempTime && tempTime <= 1000) {
					mill1000++;
				} else if (1000 < tempTime && tempTime <= 2000) {
					mill2000++;
				} else {
					mill2000M++;
				}

				if (minTime == -1)
					minTime = tempTime;
				if (maxTime == -1)
					maxTime = tempTime;
				
				if (minTime > tempTime)
					minTime = tempTime;
				if (maxTime < tempTime)
					maxTime = tempTime;
			}
		}
		totalSuccessTime =new BigDecimal(TimeUnit.NANOSECONDS.toMillis(totalSuccessTime.longValue()));
		BigDecimal minTimeDecimal = new BigDecimal(minTime);
		BigDecimal maxTimeDecimal = new BigDecimal(maxTime);
		List<Object> resultList = new ArrayList<Object>();

		resultList.add(successCount.longValue());// 0
		resultList.add(failCount.longValue());// 1
		resultList.add(totalSuccessTime.divide(successCount,scale,BigDecimal.ROUND_HALF_UP));// 2
		resultList.add(minTime);// 3
		resultList.add(maxTime);// 4
		resultList.add(mill0);// 5
		resultList.add(mill1);//6
		resultList.add(mill2);//7  
		resultList.add(mill3);//8  
		resultList.add(mill4);//9  
		resultList.add(mill5);//10  
		
		resultList.add(mill10);//11
		resultList.add(mill30);//12
		resultList.add(mill50);//13
		resultList.add(mill100);//14
		resultList.add(mill200);//15
		resultList.add(mill500);//16
		resultList.add(mill1000);//17  
		resultList.add(mill2000);//18
		resultList.add(mill2000M);//19

		log.info("Pool["+datasource+" -- "+testName+"] -- Execution times:"+ totalCount.toPlainString() + ",total time:"
				+ totalSuccessTime.toPlainString() + "ms,avg time:"
				+ (totalSuccessTime.divide(successCount, scale, BigDecimal.ROUND_HALF_UP).toPlainString())+"ms"
				+ ",min time:" + minTimeDecimal.toPlainString() + "ms,max time:" + maxTimeDecimal.toPlainString()+"ms");

		log.info("success count       :" + successCount);//0
		log.info("fail count          :" + failCount);//1
		log.info("avr(ms)             :"+ (totalSuccessTime.divide(successCount, scale, BigDecimal.ROUND_HALF_UP).toPlainString()));//2
		log.info("min(ms)             :" + minTime);//3
		log.info("max(ms)             :" + maxTime);//4
		log.info("time==0ms           :" + mill0);//5
		log.info("time==1ms           :" + mill1);//6
		log.info("time==2ms           :" + mill2);//7
		log.info("time==3ms           :" + mill3);//8
		log.info("time==4ms           :" + mill4);//9
		log.info("time==5ms           :" + mill5);//10
		log.info("5ms<time<=10ms      :" + mill10);//11
		log.info("10ms<time<=30ms     :" + mill30);//12
		log.info("30ms<time<=50ms     :" + mill50);//13
		log.info("50ms<time<=100ms    :" + mill100);//14
		log.info("100ms<time<=200ms   :" + mill200);//15
		log.info("200ms<time<=500ms   :" + mill500);//16
		log.info("500ms<time<=1000ms  :" + mill1000);//17
		log.info("1000ms<time<=2000ms :" + mill2000);//18
		log.info("2000ms<time         :" + mill2000M);//19
		return resultList;
	}
	
	public static void printAnalysis(String allPoolNames,String testName,List<TestAvg> arvgList,List<List<Object>> allPoolResultList) {
		StringBuffer buf = new StringBuffer();
		buf.append("["+testName+"]Performace analysis:");
		Collections.sort(arvgList);
		for (int i = 0; i < arvgList.size(); i++) {
			if (i > 0)
				buf.append(" > ");
			TestAvg avg = arvgList.get(i);
			buf.append(avg.getPoolName() + "(" + avg.getAvgValue().toPlainString() + ")");
		}
		log.info(buf);
		
		StringBuffer headBuffer = new StringBuffer();
		StringBuffer headBuffer2 = new StringBuffer();
		headBuffer.append("|Sumary|").append(allPoolNames.replaceAll(",", "|")).append("|");
		String head = headBuffer.toString();
		headBuffer2.append("|");
		int index =1;
		while((index=head.indexOf("|",index+1))!=-1 ){
			headBuffer2.append(" --- ").append("|");
		}
		
		List<StringBuffer> tabelList= new ArrayList<StringBuffer>(19);
		for(int i=0;i<20;i++){
			tabelList.add(new StringBuffer());
		}
		tabelList.get(0).append("|success Count");
		tabelList.get(1).append("|fail count");
		tabelList.get(2).append("|avr(ms)");
		tabelList.get(3).append("|min(ms)");
		tabelList.get(4).append("|max(ms)");
		tabelList.get(5).append("|time=0ms");
		tabelList.get(6).append("|time=1ms");
		tabelList.get(7).append("|time=2ms");
		tabelList.get(8).append("|time=3ms");
		tabelList.get(9).append("|time=4ms");
		tabelList.get(10).append("|time=5ms");
		tabelList.get(11).append("|5ms<time<=10ms");
		tabelList.get(12).append("|10ms<time<=30ms");
		tabelList.get(13).append("|30ms<time<=50ms");
		tabelList.get(14).append("|50ms<time<=100ms");
		tabelList.get(15).append("|100ms<time<=200ms");
		tabelList.get(16).append("|200ms<time<=500ms");
		tabelList.get(17).append("|500ms<time<=1000ms");
		tabelList.get(18).append("|1000ms<time<=2000ms");
		tabelList.get(19).append("|2000ms<time");
		
		int pos=0;
		for(int j=0;j<20;j++){
		    StringBuffer tempBuf = tabelList.get(j);
		    tempBuf.append("|");
		    for(int n=0;n<allPoolResultList.size();n++){
		    	List<Object> resultList = allPoolResultList.get(n);
		    	tempBuf.append(resultList.get(pos)).append("|");
		    }  
		    pos++;
		    if(j==19)tempBuf.append("|");
		}
		
		log.info(headBuffer);
		log.info(headBuffer2);
		for(int j=0;j<20;j++){
			log.info(tabelList.get(j));
		}
	}
}
