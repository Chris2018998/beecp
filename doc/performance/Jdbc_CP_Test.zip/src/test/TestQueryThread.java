package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import javax.sql.DataSource;

import org.jmin.bee.pool.util.ConnectionUtil;

/**
 *  Thread to execute SQL 
 *  
 * @author Chris
 */
class TestQueryThread extends Thread implements TestResult {
	private String SQL;
	private int loopCount;
	private long[] startTime;
	private long[] endTime;

	private DataSource datasource;
	private CountDownLatch threadLatch;
	private long targetRunMillSeconds;
	private int failedCount = 0;
	private int successCount = 0;
	
	public TestQueryThread(DataSource datasource, String SQL, int loopCount, CountDownLatch counter, long time) {
		this.SQL = SQL;
		this.datasource = datasource;
		this.threadLatch = counter;
		this.loopCount = loopCount;
		this.startTime = new long[loopCount];
		this.endTime = new long[loopCount];
		this.targetRunMillSeconds = time;
	}

	public int getFailedCount() {
		return failedCount;
	}

	public int getSuccessCount() {
		return successCount;
	}

	public long[] getStartTime() {
		return startTime;
	}

	public long[] getEndTime() {
		return endTime;
	}

	public void run() {
		long waitTime = targetRunMillSeconds - System.currentTimeMillis();
		if (waitTime <= 0)
			waitTime = 10;

		LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(waitTime));
		for (int i = 0; i < loopCount; i++) {
			startTime[i]=System.nanoTime();
			if (executeSQL(i, this.SQL)) {
				successCount++;
				endTime[i]=System.nanoTime();
			} else {
				failedCount++;
				startTime[i] =0;
				endTime[i] = 0;
			}
		}
		threadLatch.countDown();
	}

	private boolean executeSQL(int index, String sql) {
		Connection con = null;
		PreparedStatement st = null;
		try {
			con = datasource.getConnection();
			st = con.prepareStatement(sql);
			st.execute();
			return true;
		} catch (Exception e) {
			//e.printStackTrace();
			return false;
		} finally {
			ConnectionUtil.oclose(st);
			ConnectionUtil.oclose(con);
		}
	}
}