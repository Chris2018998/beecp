﻿* JDBC connection pools performance test

I: Borrow performance and query performance
1: Borrow, 1000 Threads  X  1000 iteration[datasource.getConenciton(), conneciton.close()].
2: Query,  1000 Threads  X  1000 iteration[datasource.getConenciton(), conneciton.prepareStatement(), statement.execute(), conneciton.close()].

Then print performance result
A: total time (summary all)  
B: average time per time
C: sectional statistics by per time


* II: Compared JDBC pool list
1: DBCP, Old-fashioned connection pool
2: DBCP2: Old-fashioned connection pool
3: C3P0: Old Connection Pool
4: TOMCAT-JDBC: TOMCAT new CP
5: Vibur:
6: Druid: fastest CP in China,developed by Aili(A big Chinese Internet company)
7: HikariCP: '光' means the fastest connection pool
8: BeeCP: individual study product.

* III: Performance test Requirement
1: JAVA8 (recommended 64 bits, not less than Java 8)
2: Oracle or MySQL (recommended mariadb-10.4.5-winx64)
3: CPU: Hertz as high as possible (recommended the latest version of I7 Multi-core)
4: Memory: as high as possible (recommended 16G memory)


* IV: Performance execution bat file
a: Borrow, run/TestMutilBorrow.bat

b: Query, run/TestMutilQuery.bat

* V: Performance test configuration file(Link.properties)
    DROP TABLE TEST_USER;
    CREATE TABLE TEST_USER(
      USER_ID     VARCHAR(10),
      USER_NAME   VARCHAR(10)
   );
   
	
	
	