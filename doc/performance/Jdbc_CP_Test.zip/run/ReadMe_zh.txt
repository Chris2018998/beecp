﻿工具说明：Java连接池性能测试
测试目标：模拟单线程和多线程(并发)访问连接池100万次，并打印耗时分布，平时耗时，失败次数等，最后依据平均耗时对各连接池进行排名。


耗时范围说明
1：取连接耗时 [datasource.getConenciton(), conneciton.close()]
2：查询耗时   [datasource.getConenciton(), conneciton.prepareStatement(), statement.execute(), conneciton.close()]


连接池清单(版本请见lib目录)
1：DBCP，        老牌连接池
2：DBCP2         老牌连接池
3：C3P0          老牌连接池
4：TOMCAT-JDBC   Tomcat新开发的连接池
5：Vibur:        (暂未了解)
6：Druid         中国阿里牛人温少开发，此连接池主要用于监控，而不是追求高性能
7：HikariCP      ‘光’连接池，美国大神作品（名字很吓人）
8：BeeCP         小蜜蜂连接池(人类社会的蜜蜂数量正在减少,危机。。。。。。)


测试机器配置:
1：JVM:     Java8_64(推荐使用最新版本的Java8)
2：数据库： Oracle11G或Marridb,尽量选择64位（为了减少网络开销，推荐数据库与JVM使用同一机器）
3：CPU:     频率尽量高，推荐使用新版64位多核CPU
4：内存：   8G(越高越好)


测试文件说明
1：run/TestMutilBorrow.bat  (多线程并发取连接：默认1000个线程各自执行1000次）
2：run/TestMutilQuery.bat   (多线程并发取查询：默认1000个线程各自执行1000次）
3: run/TestSingleBorrow     (单线程并发取连接: 默认1个线程各自执行100万次）
4: run/TestSingleQuery.bat  (单线程并发取查询：默认1个线程各自执行100万次））
5: run/Link.properties      (测试参数配置文件）


测试使用的表(也可更换为其他表,配置项：Link.properties/THREAD_QUERY_TABLE)
DROP TABLE TEST_USER;
CREATE TABLE TEST_USER(
  USER_ID     VARCHAR(10),
  USER_NAME   VARCHAR(10)
);


测试源码(请详见 src目录)

可依据实际情况再调整，编译后打包替换文件:lib/performance.jar


最后说明

此工具可方向性测试各连接池的性能的强弱：连接池虽然关闭所有连接，但是数据库端为了提高重用效率，可能还未来的及释放资源，

因此连续执各连接池行时，后面的连接池可能获得一定的优势。


个人邮箱：Chris2018998@tom.com, 热烈欢迎各位网友，大神，牛人，Java相关的人员交流与指正，谢谢。

 






