/*
 * Copyright Chris2018998
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jfinal.plugin.beecp;

import cn.beecp.BeeDataSource;
import cn.beecp.BeeDataSourceConfig;
import cn.beecp.TransactionIsolationLevel;
import com.jfinal.plugin.IPlugin;
import com.jfinal.plugin.activerecord.IDataSourceProvider;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

/**
 *  BeeCP datasource plugin.
 *
 *  @author Chris.Liao
 */

public class BeeCpPlugin implements IPlugin, IDataSourceProvider{
    private BeeDataSource ds=null;
    private String username;
    private String password;
    private String jdbcUrl;
    private String driverClassName;
    private String poolName;
    private boolean fairMode;
    private int initialSize;
    private int maxActive=10;
    private int borrowSemaphoreSize;
    private int preparedStatementCacheSize;
    private boolean defaultAutoCommit=true;
    private String defaultTransactionIsolation;
    private String defaultCatalog;
    private String defaultSchema;
    private boolean defaultReadOnly;
    protected long maxWait=SECONDS.toMillis(8);
    private long idleTimeout=MINUTES.toMillis(3);
    private long holdIdleTimeout=MINUTES.toMillis(5);
    private String connectionTestSQL = "select 1 from dual";
    private int connectionTestTimeout = 3;//seconds
    private long connectionTestInterval = 500L;
    private boolean forceCloseConnection;
    private long waitTimeToClearPool=3;//seconds
    private long idleCheckTimeInterval=MINUTES.toMillis(3);
    private long idleCheckTimeInitDelay=SECONDS.toMillis(1);
    private boolean enableJMX;
    private Properties connectProperties = new Properties();

    public BeeCpPlugin() {
        this(null,null,null,null);
    }
    public BeeCpPlugin(String driver, String url, String user, String password) {
        this.jdbcUrl = url;
        this.username = user;
        this.password = password;
        this.driverClassName = driver;
        defaultTransactionIsolation=TransactionIsolationLevel.LEVEL_READ_COMMITTED;
        borrowSemaphoreSize =Math.min(maxActive/2,Runtime.getRuntime().availableProcessors());
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setJdbcUrl(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
    }
    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }
    public void setPoolName(String poolName) {
        this.poolName = poolName;
    }
    public void setFairMode(boolean fairMode) {
        this.fairMode = fairMode;
    }
    public void setInitialSize(int initialSize) {
        this.initialSize = initialSize;
    }
    public void setMaxActive(int maxActive) {
        this.maxActive = maxActive;
        this.borrowSemaphoreSize=Math.min(maxActive/2,Runtime.getRuntime().availableProcessors());
    }
    public void setBorrowSemaphoreSize(int borrowSemaphoreSize) {
        this.borrowSemaphoreSize = borrowSemaphoreSize;
    }
    public void setPreparedStatementCacheSize(int preparedStatementCacheSize) {
        this.preparedStatementCacheSize = preparedStatementCacheSize;
    }
    public void setDefaultAutoCommit(boolean defaultAutoCommit) {
        this.defaultAutoCommit = defaultAutoCommit;
    }
    public void setDefaultTransactionIsolation(String defaultTransactionIsolation) {
        this.defaultTransactionIsolation = defaultTransactionIsolation;
    }
    public void setDefaultCatalog(String defaultCatalog) {
        this.defaultCatalog = defaultCatalog;
    }
    public void setDefaultSchema(String defaultSchema) {
        this.defaultSchema = defaultSchema;
    }
    public void setDefaultReadOnly(boolean defaultReadOnly) {
        this.defaultReadOnly = defaultReadOnly;
    }
    public void setMaxWait(long maxWait) {
        this.maxWait = maxWait;
    }
    public void setIdleTimeout(long idleTimeout) {
        this.idleTimeout = idleTimeout;
    }
    public void setHoldIdleTimeout(long holdIdleTimeout) {
        this.holdIdleTimeout = holdIdleTimeout;
    }
    public void setConnectionTestSQL(String connectionTestSQL) {
        this.connectionTestSQL = connectionTestSQL;
    }
    public void setConnectionTestTimeout(int connectionTestTimeout) {
        this.connectionTestTimeout = connectionTestTimeout;
    }
    public void setConnectionTestInterval(long connectionTestInterval) {
        this.connectionTestInterval = connectionTestInterval;
    }
    public void setForceCloseConnection(boolean forceCloseConnection) {
        this.forceCloseConnection = forceCloseConnection;
    }
    public void setWaitTimeToClearPool(long waitTimeToClearPool) {
        this.waitTimeToClearPool = waitTimeToClearPool;
    }
    public void setIdleCheckTimeInterval(long idleCheckTimeInterval) {
        this.idleCheckTimeInterval = idleCheckTimeInterval;
    }
    public void setIdleCheckTimeInitDelay(long idleCheckTimeInitDelay) {
        this.idleCheckTimeInitDelay = idleCheckTimeInitDelay;
    }
    public void setConnectProperties(Properties connectProperties) {
        this.connectProperties = connectProperties;
    }
    public void setEnableJMX(boolean enableJMX) {
        this.enableJMX = enableJMX;
    }
    public void removeConnectProperty(String key){
        connectProperties.remove(key);
    }
    public void addConnectProperty(String key,String value){
        connectProperties.put(key, value);
    }

    public boolean start(){
        if (ds == null){
            BeeDataSourceConfig config=new BeeDataSourceConfig();
            config.setUsername(username);
            config.setPassword(password);
            config.setJdbcUrl(jdbcUrl);
            config.setDriverClassName(driverClassName);
            config.setPoolName(poolName);
            config.setFairMode(fairMode);
            config.setInitialSize(initialSize);
            config.setMaxActive(maxActive);
            config.setBorrowSemaphoreSize(borrowSemaphoreSize);
            config.setPreparedStatementCacheSize(preparedStatementCacheSize);
            config.setDefaultAutoCommit(defaultAutoCommit);
            config.setDefaultTransactionIsolation(defaultTransactionIsolation);

            config.setDefaultCatalog(defaultCatalog);
            config.setDefaultSchema(defaultSchema);
            config.setDefaultReadOnly(defaultReadOnly);
            config.setMaxWait(maxWait);
            config.setIdleTimeout(idleTimeout);
            config.setHoldIdleTimeout(holdIdleTimeout);
            config.setConnectionTestSQL(connectionTestSQL);
            config.setConnectionTestTimeout(connectionTestTimeout);
            config.setConnectionTestInterval(connectionTestInterval);
            config.setForceCloseConnection(forceCloseConnection);
            config.setWaitTimeToClearPool(waitTimeToClearPool);
            config.setIdleCheckTimeInterval(idleCheckTimeInterval);
            config.setIdleCheckTimeInitDelay(idleCheckTimeInitDelay);
            config.setEnableJMX(enableJMX);
            Iterator<Map.Entry<Object,Object>> itor= connectProperties.entrySet().iterator();
            while(itor.hasNext()){
                Map.Entry<Object,Object> entry=itor.next();
                config.addConnectProperty(entry.getKey().toString(),entry.getValue().toString());
            }

            ds=new BeeDataSource(config);
            return true;
        }

        return false;
    }

    public boolean stop() {
        if (ds != null) {
            try {
                ds.close();
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public DataSource getDataSource(){
        return ds;
    }
}
