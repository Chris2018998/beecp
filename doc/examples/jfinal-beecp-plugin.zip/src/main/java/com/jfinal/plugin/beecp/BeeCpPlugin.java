/*
 * Copyright Chris2018998
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jfinal.plugin.beecp;

import cn.beecp.BeeDataSource;
import cn.beecp.BeeDataSourceConfig;
import cn.beecp.ConnectionFactory;
import cn.beecp.TransactionIsolationLevel;
import cn.beecp.xa.XaConnectionFactory;
import com.jfinal.plugin.IPlugin;
import com.jfinal.plugin.activerecord.IDataSourceProvider;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

/**
 *  BeeCP datasource plugin.
 *
 *  @author Chris.Liao
 */

public class BeeCpPlugin implements IPlugin, IDataSourceProvider{
    private BeeDataSource ds=null;
    //jdbc user name
    private String username;
    //jdbc password
    private String password;
    //jdbc url
    private String jdbcUrl;
    //jdbc driver class name
    private String driverClassName;

    //default set value on raw connection after it created <code>connection.setAutoCommit(String)</code>
    private String defaultCatalog;
    //default set value on raw connection after it created <code>connection.setSchema(String)</code>
    private String defaultSchema;
    //default set value on raw connection after it created <code>connection.setReadOnly(boolean)</code>
    private boolean defaultReadOnly;
    //default set value on raw connection after it created. <code>connection.setAutoCommit(boolean)</code>
    private boolean defaultAutoCommit = true;
    //default set value on raw connection after it created,<code>connection.setTransactionIsolation(int)</code>
    private int defaultTransactionIsolationCode = Connection.TRANSACTION_READ_COMMITTED;
    //default transaction isolation description,match isolation code can be set to <code>defaultTransactionIsolationCode</code>
    private String defaultTransactionIsolation = TransactionIsolationLevel.LEVEL_READ_COMMITTED;
    //a SQL to check connection active,recommend to use a simple query SQL,not contain procedure,function in SQL
    private String connectionTestSQL = "select 1 from dual";

    //pool name
    private String poolName;
    //true:fair,first arrive first take
    private boolean fairMode;
    //connection created size at pool initialization
    private int initialSize;
    //connection max size in pool
    private int maxActive = 10;
    //borrow Semaphore Size
    private int borrowSemaphoreSize = Math.min(maxActive / 2, Runtime.getRuntime().availableProcessors());
    //milliseconds:borrower request timeout
    private long maxWait = SECONDS.toMillis(8);
    //milliseconds:idle timeout connection will be removed from pool
    private long idleTimeout = MINUTES.toMillis(3);
    //milliseconds:long time not active connection hold by borrower will closed by pool
    private long holdTimeout = MINUTES.toMillis(5);
    //seconds:max time to get check active result from connection(socket readout time)
    private int connectionTestTimeout = 3;
    //milliseconds:connection test interval time from last active time
    private long connectionTestInterval = 500L;
    //milliseconds:interval time to run check task in scheduledThreadPoolExecutor
    private long idleCheckTimeInterval = MINUTES.toMillis(5);
    //using connection close indicator,true,close directly;false,delay close util them becoming idle or hold timeout
    private boolean forceCloseUsingOnClear;
    //milliseconds:delay time for next clear pooled connections when exists using connections and 'forceCloseUsingOnClear' is false
    private long delayTimeForNextClear = 3000L;

    //physical JDBC Connection factory
    private ConnectionFactory connectionFactory;
    //physical JDBC Connection factory class name
    private String connectionFactoryClassName;
    //xaConnectionFactory
    private XaConnectionFactory xaConnectionFactory;
    //xaConnection Factory ClassName
    private String xaConnectionFactoryClassName;
    //connection extra properties
    private Properties connectProperties = new Properties();
    //indicator,whether register datasource to jmx
    private boolean enableJmx;

    public BeeCpPlugin() {
        this(null,null,null,null);
    }
    public BeeCpPlugin(String driver, String url, String user, String password) {
        this.jdbcUrl = url;
        this.username = user;
        this.password = password;
        this.driverClassName = driver;
    }

    public boolean start(){
        if (ds == null){
            BeeDataSourceConfig config=new BeeDataSourceConfig();
            config.setUsername(username);
            config.setPassword(password);
            config.setJdbcUrl(jdbcUrl);
            config.setDriverClassName(driverClassName);

            config.setDefaultCatalog(defaultCatalog);
            config.setDefaultSchema(defaultSchema);
            config.setDefaultReadOnly(defaultReadOnly);
            config.setDefaultAutoCommit(defaultAutoCommit);
            config.setDefaultTransactionIsolationCode(defaultTransactionIsolationCode);
            config.setDefaultTransactionIsolation(defaultTransactionIsolation);
            config.setConnectionTestSQL(connectionTestSQL);

            config.setPoolName(poolName);
            config.setFairMode(fairMode);
            config.setInitialSize(initialSize);
            config.setMaxActive(maxActive);
            config.setBorrowSemaphoreSize(borrowSemaphoreSize);
            config.setMaxWait(maxWait);
            config.setIdleTimeout(idleTimeout);
            config.setHoldTimeout(holdTimeout);

            config.setConnectionTestTimeout(connectionTestTimeout);
            config.setConnectionTestInterval(connectionTestInterval);
            config.setIdleCheckTimeInterval(idleCheckTimeInterval);
            config.setForceCloseUsingOnClear(forceCloseUsingOnClear);
            config.setDelayTimeForNextClear(delayTimeForNextClear);

            config.setConnectionFactory(connectionFactory);
            config.setConnectionFactoryClassName(connectionFactoryClassName);
            config.setXaConnectionFactory(xaConnectionFactory);
            config.setXaConnectionFactoryClassName(xaConnectionFactoryClassName);
            config.setEnableJmx(enableJmx);

            Iterator<Map.Entry<Object,Object>> itor= connectProperties.entrySet().iterator();
            while(itor.hasNext()){
                Map.Entry<Object,Object> entry=itor.next();
                config.addConnectProperty(entry.getKey().toString(),entry.getValue());
            }

            ds=new BeeDataSource(config);
            return true;
        }

        return false;
    }

    public boolean stop() {
        if (ds != null) {
            ds.close();
            return true;
        }
        return false;
    }

    public DataSource getDataSource(){
        return ds;
    }
}
