import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import cn.beecp.BeeDataSource;
import cn.beecp.BeeDataSourceConfig;

public class ApplicationListener implements ServletContextListener{
	private static BeeDataSource ds;
	public void contextInitialized(ServletContextEvent sce) {
		BeeDataSourceConfig config = new BeeDataSourceConfig();
		config.setDriverClassName("com.mysql.jdbc.Driver");
		config.setJdbcUrl("jdbc:mysql://localhost/test");
		config.setUsername("root");
		//config.setPassword();
		config.setMaxActive(10);
		config.setInitialSize(0);
		config.setMaxWait(8000);//ms
		ds=new BeeDataSource(config);
	}

    public void contextDestroyed(ServletContextEvent sce) {  
    	if(ds!=null){
    		ds.close();
    	}
    }

}
