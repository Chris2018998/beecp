﻿1: 本地启动MySQL数据库
2: 执行insert.sql写入数据到test数据中
3: 将当前tomcat目录下的两个目录覆盖tomcat下同名子目录
4: 将BeeCP目录包拷贝到webapp目录中
5: 启动tomcat(我测试使用的tomcat7)
6: 访问页面:http://localhost:8080/BeeCP/